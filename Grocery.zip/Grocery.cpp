/*
 * Grocery.cpp
 *
 *  Date: [04/19/2024]
 *  Author: [Roy Acevedo]
 */


#include <iostream>
#include <fstream>
#include <map>

using namespace std;

class ItemTracker {
    private:
        map<string, int> itemFreqMap;

    public:
        // Constructor
        ItemTracker() {}

        // Load input file and update item frequency map
        void loadInputFile(string fileName) {
            ifstream inputFile(fileName);
            string item;
            while (inputFile >> item) {
                itemFreqMap[item]++;
            }
        }

        // Save item frequency data to a file
        void saveFrequencyData(string fileName) {
            ofstream outputFile(fileName);
            for (auto const &item : itemFreqMap) {
                outputFile << item.first << " " << item.second << endl;
            }
            outputFile.close();
        }

        // Get frequency of a specific item
        int getItemFrequency(string item) {
            if (itemFreqMap.find(item) == itemFreqMap.end()) {
                return 0;
            } else {
                return itemFreqMap[item];
            }
        }

        // Print frequency of all items
        void printItemFrequency() {
            for (auto const &item : itemFreqMap) {
                cout << item.first << " " << item.second << endl;
            }
        }

        // Print item histogram
        void printItemHistogram() {
            int maxFreq = 0;
            for (auto const &item : itemFreqMap) {
                if (item.second > maxFreq) {
                    maxFreq = item.second;
                }
            }
            for (auto const &item : itemFreqMap) {
                cout << item.first << " ";
                for (int i = 0; i < item.second; i++) {
                    cout << "*";
                }
                cout << endl;
            }
        }
};

int main() {
    ItemTracker tracker;
    // Load input file and save frequency data
    tracker.loadInputFile("CS210_Project_Three_Input_File.txt");
    tracker.saveFrequencyData("frequency.dat");

    int choice;
    string item;
    do {
        // Display menu options
        cout << "\n1. Get frequency of item";
        cout << "\n2. Print frequency of all items";
        cout << "\n3. Print item histogram";
        cout << "\n4. Exit";
        cout << "\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                // Get frequency of a specific item
                cout << "Enter the item you want to search: ";
                cin >> item;
                cout << "Frequency of " << item << ": " << tracker.getItemFrequency(item) << endl;
                break;
            case 2:
                // Print frequency of all items
                tracker.printItemFrequency();
                break;
            case 3:
                // Print item histogram
                tracker.printItemHistogram();
                break;
            case 4:
                // Exit the program
                cout << "Exiting program..." << endl;
                break;
            default:
                // Invalid choice
                cout << "Invalid choice. Please enter a valid option." << endl;
        }
    } while (choice != 4);

    return 0;
}
